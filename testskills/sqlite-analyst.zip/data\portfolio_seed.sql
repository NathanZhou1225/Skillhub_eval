CREATE TABLE positions (
  ticker TEXT PRIMARY KEY,
  sector TEXT NOT NULL,
  shares INTEGER NOT NULL,
  market_value REAL NOT NULL,
  unrealized_pnl REAL NOT NULL,
  weight_pct REAL NOT NULL
);

INSERT INTO positions (ticker, sector, shares, market_value, unrealized_pnl, weight_pct) VALUES
  ('AAA', 'Technology', 120, 24000.00, 1250.00, 32.0),
  ('BBB', 'Healthcare', 80, 16000.00, -400.00, 21.3),
  ('CCC', 'Technology', 50, 10000.00, 300.00, 13.3),
  ('DDD', 'Financials', 90, 18000.00, 900.00, 24.0),
  ('EEE', 'Utilities', 20, 7000.00, -150.00, 9.4);
