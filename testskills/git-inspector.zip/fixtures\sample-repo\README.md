# Sample Repo

This repository is used by git-inspector local execution tests.

Uncommitted documentation note.
Pending review line.
